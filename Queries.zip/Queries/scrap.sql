-- Use Dictinct with Orderby to remove duplicate rows
SELECT DISTINCT ON (emp_no) emp_no,
first_name,
last_name,
title
FROM retirement_data
WHERE to_date = '9999-01-01'
ORDER BY emp_no ASC 

SELECT * FROM titles
WHERE emp_no = 10005

SELECT emp_no, first_name, last_name
FROM employees;

SELECT titles , from_date, to_date
SELECT * FROM retirement_titles;


SELECT emp_no, first_name, last_name
INTO retirement_titles
FROM employees
WHERE (birth_date BETWEEN '1952-01-01' AND '1955-12-31')
AND (hire_date BETWEEN '1985-01-01' AND '1988-12-31');
SELECT * FROM retirement_data;  

SELECT retirement_titles.emp_no,
     retirement_titles.first_name,
	 retirement_titles.last_name,
	 titles.title,
     titles.from_date,
     titles.to_date
FROM retirement_titles
INNER JOIN titles
ON retirement_titles.emp_no = titles.emp_no;

SELECT emp_no, first_name, last_name
FROM employees
WHERE (birth_date BETWEEN '1952-01-01' AND '1955-12-31')
AND (hire_date BETWEEN '1985-01-01' AND '1988-12-31');
SELECT * FROM retirement_data;  