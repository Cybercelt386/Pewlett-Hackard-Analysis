# Pewlett-Hackard-Analysis

## Purpose
The purpose of this analaysis is to determine how many of Pewlett-Heckards senior employees are prepairing to go into retirement. This is important information for the company because not only will these positions need to be filled but a wealth of knowlage and expiriance will be leaving the company when these employees retire. To that end we have created a list of suitable mentors to train up the next generation. 

## Results 
In my analysis I created a database to store information about the companies employees. Created  tables to store that information then filtered that data int new tables with the INTO clause sorting out just the information relative to my analysis. The results of this analysis are: 

* The Number of retiring employeees: 33118 employees 

* 

* 