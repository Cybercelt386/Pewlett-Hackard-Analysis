-- Use Dictinct with Orderby to remove duplicate rows
SELECT DISTINCT ON (emp_no) emp_no,
first_name,
last_name,
birth_date,
from_date,
to_date,
title
INTO mentorship_eligability
FROM mentors_emp
WHERE (birth_date BETWEEN '1965-01-01' AND '1965-12-31')
ORDER BY emp_no;

WHERE to_date = '9999-01-01'

SELECT emp_no, first_name, last_name
FROM employees 
WHERE (birth_date BETWEEN '1952-01-01' AND '1955-12-31')
AND (hire_date BETWEEN '1985-01-01' AND '1988-12-31');

SELECT title, from_date, to_date
FROM titles; 

select * from titles;
-- Joining departments and dept_manager tables
SELECT retirement_info.emp_no,
     retirement_info.first_name,
	 retirement_info.last_name,
	 titles.title,
     titles.from_date,
     titles.to_date
FROM retirement_info
INNER JOIN titles
ON retirement_info.emp_no = titles.emp_no;

CREATE TABLE retirement_data (
	emp_no INT NOT NULL,
	first_name VARCHAR(20) NOT NULL,
	last_name VARCHAR(20) NOT NULL,
	title VARCHAR(40) NOT NULL, 
	from_date VARCHAR(15) NOT NULL,
	to_date VARCHAR(15) NOT NULL,
FOREIGN KEY (emp_no) REFERENCES employees (emp_no),
	PRIMARY KEY (emp_no, from_date)
);

SELECT employees.emp_no, 
       employees.first_name, 
       employees.last_name, 
	   employees.birth_date,
	   dept_employee.from_date,
	   dept_employee.to_date
FROM employees
INNER JOIN dept_employee
ON employees.emp_no = dept_employee.emp_no;

SELECT mentors.emp_no, 
       mentors.first_name, 
       mentors.last_name, 
	   mentors.birth_date,
	   mentors.from_date,
	   mentors.to_date,
	   titles.title
INTO mentors_emp
FROM mentors
INNER JOIN titles
ON mentors.emp_no = titles.emp_no;
	   
SELECT DISTINCT ON (emp_no) emp_no,
first_name,
last_name,
title

FROM mentors
WHERE to_date = '9999-01-01'
ORDER BY emp_no, to_date DESC;	  

SELECT COUNT (EMP_NO) AS count_retirement_employees
from retirement_employees;

SELECT COUNT (EMP_NO) AS count_mentorship_eligability
from retirement_employees;


-- quick access queries
SELECT * FROM mentorship_eligability;
SELECT * FROM titles;
SELECT * FROM employees;
SELECT * FROM dept_employee;
SELECT * FROM retirement_titles;
SELECT * FROM retirement_info;
SELECT * FROM retirement_data;
SELECT * FROM retirement_employees;